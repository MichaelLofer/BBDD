﻿SELECT "Codigo_Barras", "PvP"
	FROM "Articulo"