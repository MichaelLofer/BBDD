﻿SELECT "Numero_surtidor","Fecha_Reapertura"
	FROM "Surtidor"
	WHERE "Fecha_Reapertura" IS NOT NULL