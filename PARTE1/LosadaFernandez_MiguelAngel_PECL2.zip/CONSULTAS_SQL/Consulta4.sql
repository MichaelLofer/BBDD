﻿SELECT "Nombre"
	FROM "Empleado"
	WHERE "Empleado"."Turno" = 'MAÑANA' AND "Empleado"."Numero_surtidor" IS NULL