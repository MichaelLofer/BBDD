﻿SELECT COUNT (*)
	FROM "Surtidor"